// ORBIT Popup Script
// Handles settings, configuration, and user interactions

console.log('🚀 ORBIT Popup Loaded');

// DOM Elements
const elements = {
  setupSection: document.getElementById('setup-section'),
  dashboardSection: document.getElementById('dashboard-section'),
  statusIcon: document.getElementById('status-icon'),
  statusTitle: document.getElementById('status-title'),
  statusDesc: document.getElementById('status-desc'),
  aiProvider: document.getElementById('ai-provider'),
  apiKey: document.getElementById('api-key'),
  saveSettings: document.getElementById('save-settings'),
  testResult: document.getElementById('test-result'),
  statResponses: document.getElementById('stat-responses'),
  statTime: document.getElementById('stat-time'),
  statComments: document.getElementById('stat-comments'),
  currentProvider: document.getElementById('current-provider'),
  currentTone: document.getElementById('current-tone'),
  autoAnalyze: document.getElementById('auto-analyze'),
  changeProvider: document.getElementById('change-provider'),
  changeTone: document.getElementById('change-tone'),
  viewDocs: document.getElementById('view-docs'),
  exportData: document.getElementById('export-data'),
  resetSettings: document.getElementById('reset-settings'),
  toneButtons: document.querySelectorAll('.tone-btn')
};

let currentSettings = {
  aiProvider: 'openai',
  apiKey: '',
  defaultTone: 'professional',
  autoAnalyze: true
};

let selectedTone = 'professional';

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  await loadStats();
  setupEventListeners();
});

// Load saved settings
async function loadSettings() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getSettings' });
    if (response.success && response.settings) {
      currentSettings = { ...currentSettings, ...response.settings };
      updateUI();
    }
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

// Update UI based on settings
function updateUI() {
  // Update provider select
  elements.aiProvider.value = currentSettings.aiProvider;
  
  // Update tone buttons
  elements.toneButtons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tone === currentSettings.defaultTone);
  });
  selectedTone = currentSettings.defaultTone;
  
  // Update auto-analyze toggle
  elements.autoAnalyze.checked = currentSettings.autoAnalyze;
  
  // Check if configured
  checkConfiguration();
}

// Check if ORBIT is configured
async function checkConfiguration() {
  const apiKey = await getStoredAPIKey();
  
  if (apiKey && apiKey.length > 10) {
    // Show dashboard
    elements.setupSection.classList.add('hidden');
    elements.dashboardSection.classList.remove('hidden');
    
    // Update status
    elements.statusIcon.innerHTML = '<span class="status-dot active"></span>';
    elements.statusTitle.textContent = 'Active';
    elements.statusDesc.textContent = 'ORBIT is ready to help';
    
    // Update current values
    const providerNames = {
      openai: 'OpenAI',
      anthropic: 'Anthropic',
      google: 'Google Gemini',
      groq: 'Groq'
    };
    elements.currentProvider.textContent = providerNames[currentSettings.aiProvider] || currentSettings.aiProvider;
    elements.currentTone.textContent = currentSettings.defaultTone.charAt(0).toUpperCase() + currentSettings.defaultTone.slice(1);
  } else {
    // Show setup
    elements.setupSection.classList.remove('hidden');
    elements.dashboardSection.classList.add('hidden');
    
    // Update status
    elements.statusIcon.innerHTML = '<span class="status-dot"></span>';
    elements.statusTitle.textContent = 'Not Configured';
    elements.statusDesc.textContent = 'Set up your AI provider to get started';
  }
}

// Load stats
async function loadStats() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getStats' });
    if (response.success && response.stats) {
      elements.statResponses.textContent = response.stats.responsesGenerated || 0;
      elements.statTime.textContent = Math.floor((response.stats.timeSaved || 0) / 60) + 'h';
      elements.statComments.textContent = response.stats.commentsAnalyzed || 0;
    }
  } catch (error) {
    console.error('Failed to load stats:', error);
  }
}

// Setup event listeners
function setupEventListeners() {
  // Tone selection
  elements.toneButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      elements.toneButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedTone = btn.dataset.tone;
    });
  });
  
  // Save settings
  elements.saveSettings.addEventListener('click', saveSettingsHandler);
  
  // Change provider
  elements.changeProvider.addEventListener('click', () => {
    elements.setupSection.classList.remove('hidden');
    elements.dashboardSection.classList.add('hidden');
    elements.apiKey.value = '';
  });
  
  // Change tone
  elements.changeTone.addEventListener('click', () => {
    elements.setupSection.classList.remove('hidden');
    elements.dashboardSection.classList.add('hidden');
  });
  
  // Auto-analyze toggle
  elements.autoAnalyze.addEventListener('change', async () => {
    currentSettings.autoAnalyze = elements.autoAnalyze.checked;
    await chrome.runtime.sendMessage({
      action: 'saveSettings',
      data: currentSettings
    });
  });
  
  // View docs button
  elements.viewDocs.addEventListener('click', () => {
    alert('📄 Product docs feature coming soon!\n\nYou\'ll be able to upload FAQs, product descriptions, and brand guidelines to help ORBIT generate better responses.');
  });
  
  // Export data
  elements.exportData.addEventListener('click', exportStats);
  
  // Reset settings
  elements.resetSettings.addEventListener('click', resetSettings);
  
  // Help links
  document.getElementById('get-api-key').addEventListener('click', showAPIKeyHelp);
  document.getElementById('help-link').addEventListener('click', () => {
    window.open('https://orbitsales.ai/help', '_blank');
  });
  document.getElementById('privacy-link').addEventListener('click', () => {
    window.open('https://orbitsales.ai/privacy', '_blank');
  });
  document.getElementById('feedback-link').addEventListener('click', () => {
    window.open('https://orbitsales.ai/feedback', '_blank');
  });
}

// Save settings handler
async function saveSettingsHandler() {
  const provider = elements.aiProvider.value;
  const apiKey = elements.apiKey.value.trim();
  
  if (!apiKey) {
    showTestResult('Please enter an API key', false);
    return;
  }
  
  // Show testing state
  elements.saveSettings.textContent = 'Testing API...';
  elements.saveSettings.disabled = true;
  
  try {
    // Test API connection
    const testResponse = await chrome.runtime.sendMessage({
      action: 'testAPI',
      data: { provider, apiKey }
    });
    
    if (testResponse.success) {
      // Save settings
      currentSettings = {
        aiProvider: provider,
        defaultTone: selectedTone,
        autoAnalyze: true
      };
      
      await chrome.runtime.sendMessage({
        action: 'saveSettings',
        data: currentSettings
      });
      
      // Save API key
      await chrome.storage.local.set({ [`apiKey_${provider}`]: apiKey });
      
      showTestResult('✅ API connection successful!', true);
      
      // Update UI
      setTimeout(() => {
        updateUI();
        elements.saveSettings.textContent = 'Save & Activate';
        elements.saveSettings.disabled = false;
        elements.apiKey.value = '';
      }, 1000);
    } else {
      showTestResult('❌ ' + testResponse.error, false);
      elements.saveSettings.textContent = 'Save & Activate';
      elements.saveSettings.disabled = false;
    }
  } catch (error) {
    showTestResult('❌ Failed to test API: ' + error.message, false);
    elements.saveSettings.textContent = 'Save & Activate';
    elements.saveSettings.disabled = false;
  }
}

// Show test result
function showTestResult(message, isSuccess) {
  elements.testResult.textContent = message;
  elements.testResult.className = 'test-result ' + (isSuccess ? 'success' : 'error');
  
  setTimeout(() => {
    elements.testResult.className = 'test-result';
    elements.testResult.textContent = '';
  }, 5000);
}

// Get stored API key
async function getStoredAPIKey() {
  const key = `apiKey_${currentSettings.aiProvider}`;
  const result = await chrome.storage.local.get(key);
  return result[key] || '';
}

// Export stats
async function exportStats() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getStats' });
    if (response.success) {
      const data = {
        ...response.stats,
        exportDate: new Date().toISOString(),
        version: '1.0.0'
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `orbit-stats-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
    }
  } catch (error) {
    console.error('Export failed:', error);
    alert('Failed to export stats');
  }
}

// Reset settings
async function resetSettings() {
  if (confirm('⚠️ Are you sure?\n\nThis will reset all ORBIT settings and remove your API key. You\'ll need to set up ORBIT again.')) {
    await chrome.storage.local.clear();
    currentSettings = {
      aiProvider: 'openai',
      defaultTone: 'professional',
      autoAnalyze: true
    };
    elements.apiKey.value = '';
    updateUI();
    alert('Settings reset. Please configure ORBIT again.');
  }
}

// Show API key help
function showAPIKeyHelp() {
  const provider = elements.aiProvider.value;
  const urls = {
    openai: 'https://platform.openai.com/api-keys',
    anthropic: 'https://console.anthropic.com/settings/keys',
    google: 'https://makersuite.google.com/app/apikey',
    groq: 'https://console.groq.com/keys'
  };
  
  const messages = {
    openai: `To get your OpenAI API key:\n\n1. Visit platform.openai.com/api-keys\n2. Sign up or log in\n3. Click "Create new secret key"\n4. Copy and paste it here\n\nNote: You'll need to add billing to use the API.`,
    anthropic: `To get your Anthropic API key:\n\n1. Visit console.anthropic.com\n2. Sign up for access\n3. Go to Settings → API Keys\n4. Create a new key and copy it here`,
    google: `To get your Google Gemini API key:\n\n1. Visit makersuite.google.com\n2. Sign in with Google\n3. Click "Get API key"\n4. Copy and paste it here`,
    groq: `To get your Groq API key:\n\n1. Visit console.groq.com\n2. Sign up for free\n3. Go to API Keys\n4. Create a new key and copy it here\n\nGroq offers fast inference at low cost!`
  };
  
  if (confirm(messages[provider] + '\n\nWould you like to open the website?')) {
    window.open(urls[provider], '_blank');
  }
}

console.log('✅ ORBIT Popup Ready');