// ORBIT Background Service Worker
// Handles API calls, storage, and cross-tab communication

console.log('🚀 ORBIT Background Service Worker Initialized');

// Configuration
const CONFIG = {
  VERSION: '1.0.0',
  API_TIMEOUT: 30000,
  MAX_RETRIES: 3
};

// Supported AI Providers
const AI_PROVIDERS = {
  openai: {
    name: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1',
    models: ['gpt-4', 'gpt-4-turbo', 'gpt-3.5-turbo']
  },
  anthropic: {
    name: 'Anthropic',
    baseUrl: 'https://api.anthropic.com/v1',
    models: ['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku']
  },
  google: {
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1',
    models: ['gemini-pro', 'gemini-ultra']
  },
  groq: {
    name: 'Groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    models: ['llama3-70b', 'llama3-8b', 'mixtral-8x7b']
  }
};

// Initialize extension
chrome.runtime.onInstalled.addListener((details) => {
  console.log('ORBIT installed:', details.reason);
  
  // Set default settings
  chrome.storage.local.set({
    settings: {
      aiProvider: 'openai',
      defaultTone: 'professional',
      autoAnalyze: true,
      showAnalytics: true,
      language: 'en'
    },
    stats: {
      commentsAnalyzed: 0,
      responsesGenerated: 0,
      timeSaved: 0,
      lastActive: Date.now()
    }
  });
});

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received:', request.action);
  
  switch (request.action) {
    case 'generateReply':
      handleGenerateReply(request.data).then(sendResponse);
      return true; // Keep channel open for async
      
    case 'analyzeSales':
      handleAnalyzeSales(request.data).then(sendResponse);
      return true;
      
    case 'getKeywords':
      handleKeywordAnalysis(request.data).then(sendResponse);
      return true;
      
    case 'getSettings':
      handleGetSettings().then(sendResponse);
      return true;
      
    case 'saveSettings':
      handleSaveSettings(request.data).then(sendResponse);
      return true;
      
    case 'testAPI':
      handleTestAPI(request.data).then(sendResponse);
      return true;
      
    case 'getStats':
      handleGetStats().then(sendResponse);
      return true;
  }
});

// Generate AI reply
async function handleGenerateReply(data) {
  try {
    const { settings } = await chrome.storage.local.get('settings');
    const apiKey = await getDecryptedAPIKey(settings.aiProvider);
    
    if (!apiKey) {
      return { success: false, error: 'API key not configured' };
    }
    
    const prompt = buildReplyPrompt(data, settings);
    const response = await callAIProvider(settings.aiProvider, apiKey, prompt);
    
    // Update stats
    await updateStats('responsesGenerated');
    await updateStats('timeSaved', 5); // Assume 5 min saved per response
    
    return { success: true, reply: response };
  } catch (error) {
    console.error('Generate reply error:', error);
    return { success: false, error: error.message };
  }
}

// Analyze sales data
async function handleAnalyzeSales(data) {
  try {
    const { settings } = await chrome.storage.local.get('settings');
    const apiKey = await getDecryptedAPIKey(settings.aiProvider);
    
    if (!apiKey) {
      return { success: false, error: 'API key not configured' };
    }
    
    const prompt = buildAnalyticsPrompt(data);
    const analysis = await callAIProvider(settings.aiProvider, apiKey, prompt);
    
    return { success: true, analysis: JSON.parse(analysis) };
  } catch (error) {
    console.error('Analyze sales error:', error);
    return { success: false, error: error.message };
  }
}

// Keyword analysis
async function handleKeywordAnalysis(data) {
  try {
    const { settings } = await chrome.storage.local.get('settings');
    const apiKey = await getDecryptedAPIKey(settings.aiProvider);
    
    if (!apiKey) {
      return { success: false, error: 'API key not configured' };
    }
    
    const prompt = buildKeywordPrompt(data);
    const analysis = await callAIProvider(settings.aiProvider, apiKey, prompt);
    
    await updateStats('commentsAnalyzed', data.comments.length);
    
    return { success: true, keywords: JSON.parse(analysis) };
  } catch (error) {
    console.error('Keyword analysis error:', error);
    return { success: false, error: error.message };
  }
}

// Build reply generation prompt
function buildReplyPrompt(data, settings) {
  const tones = {
    professional: 'professional and courteous',
    friendly: 'warm and approachable',
    technical: 'detailed and technical',
    apologetic: 'empathetic and solution-oriented'
  };
  
  return `You are a helpful customer support assistant. Generate a ${tones[settings.defaultTone]} response to this customer comment.

Product Context:
${data.productContext || 'No additional context provided'}

Customer Information:
- Name: ${data.customerName}
- Tier: ${data.customerTier}
- Purchase Date: ${data.purchaseDate}

Comment:
"${data.comment}"

Guidelines:
- Address the customer by name
- Be concise but thorough
- Include specific details from product context if relevant
- Maintain a ${settings.defaultTone} tone
- End with an appropriate closing

Generate only the response text, no explanations.`;
}

// Build analytics prompt
function buildAnalyticsPrompt(data) {
  return `Analyze this sales data and provide actionable insights in JSON format.

Sales Data:
${JSON.stringify(data, null, 2)}

Provide analysis in this JSON structure:
{
  "summary": "Brief overview",
  "keyInsights": [
    {
      "type": "opportunity|warning|trend",
      "title": "Insight title",
      "description": "Detailed explanation",
      "action": "Recommended action"
    }
  ],
  "metrics": {
    "totalRevenue": number,
    "conversionRate": number,
    "refundRate": number,
    "avgOrderValue": number
  }
}`;
}

// Build keyword analysis prompt
function buildKeywordPrompt(data) {
  return `Analyze these customer comments and extract insights in JSON format.

Comments:
${JSON.stringify(data.comments, null, 2)}

Provide analysis in this JSON structure:
{
  "featureRequests": [
    {"feature": "name", "mentions": number, "priority": "high|medium|low"}
  ],
  "painPoints": [
    {"issue": "description", "mentions": number, "trend": "increasing|stable|decreasing"}
  ],
  "sentiment": {
    "overall": "positive|neutral|negative",
    "score": number
  },
  "competitors": [
    {"name": "competitor", "mentions": number, "context": "positive|negative"}
  ]
}`;
}

// Call AI provider API
async function callAIProvider(provider, apiKey, prompt) {
  const providerConfig = AI_PROVIDERS[provider];
  
  if (!providerConfig) {
    throw new Error(`Unknown provider: ${provider}`);
  }
  
  let response;
  
  switch (provider) {
    case 'openai':
      response = await fetch(`${providerConfig.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7,
          max_tokens: 500
        })
      });
      break;
      
    case 'anthropic':
      response = await fetch(`${providerConfig.baseUrl}/messages`, {
        method: 'POST',
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json',
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-3-haiku-20240307',
          max_tokens: 500,
          messages: [{ role: 'user', content: prompt }]
        })
      });
      break;
      
    case 'google':
      response = await fetch(`${providerConfig.baseUrl}/models/gemini-pro:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }]
        })
      });
      break;
      
    case 'groq':
      response = await fetch(`${providerConfig.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'llama3-8b-8192',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7,
          max_tokens: 500
        })
      });
      break;
  }
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`API error: ${error}`);
  }
  
  const result = await response.json();
  
  // Extract text based on provider response format
  switch (provider) {
    case 'openai':
      return result.choices[0].message.content;
    case 'anthropic':
      return result.content[0].text;
    case 'google':
      return result.candidates[0].content.parts[0].text;
    case 'groq':
      return result.choices[0].message.content;
    default:
      return result;
  }
}

// Settings management
async function handleGetSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { success: true, settings };
}

async function handleSaveSettings(data) {
  await chrome.storage.local.set({ settings: data });
  return { success: true };
}

// API key management (encrypted storage)
async function getDecryptedAPIKey(provider) {
  const key = `apiKey_${provider}`;
  const result = await chrome.storage.local.get(key);
  return result[key] || null;
}

async function handleTestAPI(data) {
  try {
    const prompt = 'Say "ORBIT API connection successful" if you can read this.';
    await callAIProvider(data.provider, data.apiKey, prompt);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// Stats management
async function handleGetStats() {
  const { stats } = await chrome.storage.local.get('stats');
  return { success: true, stats };
}

async function updateStats(key, increment = 1) {
  const { stats } = await chrome.storage.local.get('stats');
  stats[key] = (stats[key] || 0) + increment;
  stats.lastActive = Date.now();
  await chrome.storage.local.set({ stats });
}

// Tab management
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Check if we're on a supported platform
    const supportedSites = [
      'appsumo.com',
      'gumroad.com',
      'lemonsqueezy.com'
    ];
    
    const isSupported = supportedSites.some(site => tab.url.includes(site));
    
    if (isSupported) {
      chrome.action.setBadgeText({ text: '●', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#00d4ff' });
    }
  }
});

console.log('✅ ORBIT Background Service Worker Ready');