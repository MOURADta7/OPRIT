// ORBIT Content Script
// Injects AI assistant into marketplace dashboards

console.log('🚀 ORBIT Content Script Loaded');

// Platform detection
const PLATFORM = detectPlatform();
console.log('Platform detected:', PLATFORM);

// State management
let orbitState = {
  isActive: false,
  comments: [],
  salesData: null,
  uiInjected: false
};

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeOrbit);
} else {
  initializeOrbit();
}

function detectPlatform() {
  const url = window.location.href;
  if (url.includes('appsumo.com')) return 'appsumo';
  if (url.includes('gumroad.com')) return 'gumroad';
  if (url.includes('lemonsqueezy.com')) return 'lemonsqueezy';
  return 'unknown';
}

async function initializeOrbit() {
  console.log('Initializing ORBIT on', PLATFORM);
  
  // Check if user has configured ORBIT
  const { settings } = await chrome.storage.local.get('settings');
  if (!settings) {
    console.log('ORBIT not configured yet');
    return;
  }
  
  orbitState.isActive = true;
  
  // Inject UI components
  injectOrbitUI();
  
  // Start observing for dynamic content
  observeDashboardChanges();
  
  // Extract initial data
  extractDashboardData();
  
  console.log('✅ ORBIT initialized successfully');
}

// Inject ORBIT floating widget and overlay
function injectOrbitUI() {
  if (orbitState.uiInjected) return;
  
  // Create main container
  const orbitContainer = document.createElement('div');
  orbitContainer.id = 'orbit-container';
  orbitContainer.innerHTML = `
    <div id="orbit-widget" class="orbit-widget">
      <div class="orbit-widget-header">
        <div class="orbit-logo">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#00d4ff" stroke-width="2"/>
            <circle cx="12" cy="12" r="4" fill="#00d4ff"/>
            <path d="M12 2 L12 6 M12 18 L12 22 M2 12 L6 12 M18 12 L22 12" stroke="#00d4ff" stroke-width="2"/>
          </svg>
          <span>ORBIT</span>
        </div>
        <div class="orbit-status">
          <span class="status-dot active"></span>
          <span class="status-text">Active</span>
        </div>
      </div>
      
      <div class="orbit-widget-body">
        <button id="orbit-toggle-analytics" class="orbit-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="9" y1="9" x2="9" y2="15"/>
            <line x1="15" y1="9" x2="15" y2="15"/>
          </svg>
          Analytics
        </button>
        
        <button id="orbit-analyze-all" class="orbit-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="16"/>
            <line x1="8" y1="12" x2="16" y2="12"/>
          </svg>
          AI Insights
        </button>
        
        <button id="orbit-keywords" class="orbit-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          Keywords
        </button>
      </div>
      
      <div class="orbit-quick-stats">
        <div class="stat-item">
          <span class="stat-value" id="orbit-stat-responses">0</span>
          <span class="stat-label">Responses</span>
        </div>
        <div class="stat-item">
          <span class="stat-value" id="orbit-stat-time">0h</span>
          <span class="stat-label">Saved</span>
        </div>
      </div>
    </div>
    
    <div id="orbit-analytics-panel" class="orbit-analytics-panel hidden">
      <div class="panel-header">
        <h3>📊 Sales Analytics</h3>
        <button id="orbit-close-analytics" class="orbit-icon-btn">×</button>
      </div>
      <div class="panel-content" id="orbit-analytics-content">
        <div class="loading">Analyzing your data...</div>
      </div>
    </div>
    
    <div id="orbit-keywords-panel" class="orbit-keywords-panel hidden">
      <div class="panel-header">
        <h3>🔍 Keyword Intelligence</h3>
        <button id="orbit-close-keywords" class="orbit-icon-btn">×</button>
      </div>
      <div class="panel-content" id="orbit-keywords-content">
        <div class="loading">Scanning comments...</div>
      </div>
    </div>
  `;
  
  document.body.appendChild(orbitContainer);
  
  // Add event listeners
  document.getElementById('orbit-toggle-analytics').addEventListener('click', toggleAnalytics);
  document.getElementById('orbit-close-analytics').addEventListener('click', toggleAnalytics);
  document.getElementById('orbit-analyze-all').addEventListener('click', analyzeDashboard);
  document.getElementById('orbit-keywords').addEventListener('click', analyzeKeywords);
  document.getElementById('orbit-close-keywords').addEventListener('click', () => {
    document.getElementById('orbit-keywords-panel').classList.add('hidden');
  });
  
  // Update stats
  updateQuickStats();
  
  orbitState.uiInjected = true;
}

// Inject reply buttons on comments
function injectReplyButtons() {
  const comments = findComments();
  
  comments.forEach((comment, index) => {
    // Check if already has ORBIT button
    if (comment.querySelector('.orbit-reply-btn')) return;
    
    const replyBtn = document.createElement('button');
    replyBtn.className = 'orbit-reply-btn';
    replyBtn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      Generate AI Reply
    `;
    replyBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      generateReplyForComment(comment, index);
    });
    
    // Find appropriate place to insert
    const actionsContainer = comment.querySelector('.actions, .comment-actions, [class*="action"]');
    if (actionsContainer) {
      actionsContainer.appendChild(replyBtn);
    } else {
      comment.appendChild(replyBtn);
    }
  });
  
  orbitState.comments = comments;
}

// Find comment elements on the page
function findComments() {
  const selectors = {
    appsumo: ['.comment', '[data-testid="comment"]', '.review-item'],
    gumroad: ['.comment', '.review', '[class*="comment"]'],
    lemonsqueezy: ['.comment', '.review-card']
  };
  
  const platformSelectors = selectors[PLATFORM] || selectors.appsumo;
  let comments = [];
  
  for (const selector of platformSelectors) {
    comments = document.querySelectorAll(selector);
    if (comments.length > 0) break;
  }
  
  return Array.from(comments);
}

// Generate AI reply for a specific comment
async function generateReplyForComment(commentElement, index) {
  const btn = commentElement.querySelector('.orbit-reply-btn');
  btn.disabled = true;
  btn.innerHTML = `<span class="orbit-spinner"></span> Generating...`;
  
  // Extract comment data
  const commentData = extractCommentData(commentElement);
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'generateReply',
      data: commentData
    });
    
    if (response.success) {
      showReplyModal(commentElement, response.reply, commentData);
    } else {
      alert('Error: ' + response.error);
    }
  } catch (error) {
    console.error('Error generating reply:', error);
    alert('Failed to generate reply. Please check your API settings.');
  } finally {
    btn.disabled = false;
    btn.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      Generate AI Reply
    `;
  }
}

// Extract comment data from DOM
function extractCommentData(commentElement) {
  return {
    comment: commentElement.textContent || '',
    customerName: commentElement.querySelector('[class*="author"], [class*="name"], .username')?.textContent || 'Customer',
    customerTier: 'Unknown', // Would need platform-specific extraction
    purchaseDate: 'Unknown',
    productContext: '' // Would be set from user's uploaded docs
  };
}

// Show reply modal with generated text
function showReplyModal(commentElement, reply, commentData) {
  // Remove existing modal
  const existingModal = document.getElementById('orbit-reply-modal');
  if (existingModal) existingModal.remove();
  
  const modal = document.createElement('div');
  modal.id = 'orbit-reply-modal';
  modal.className = 'orbit-modal';
  modal.innerHTML = `
    <div class="orbit-modal-overlay"></div>
    <div class="orbit-modal-content">
      <div class="orbit-modal-header">
        <h3>🤖 AI-Generated Reply</h3>
        <button class="orbit-close-modal">×</button>
      </div>
      <div class="orbit-modal-body">
        <div class="reply-preview">
          <textarea id="orbit-reply-text" rows="6">${reply}</textarea>
        </div>
        <div class="reply-actions">
          <button id="orbit-copy-reply" class="orbit-btn secondary">Copy</button>
          <button id="orbit-insert-reply" class="orbit-btn primary">Insert & Post</button>
        </div>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Event listeners
  modal.querySelector('.orbit-close-modal').addEventListener('click', () => modal.remove());
  modal.querySelector('.orbit-modal-overlay').addEventListener('click', () => modal.remove());
  
  document.getElementById('orbit-copy-reply').addEventListener('click', () => {
    const text = document.getElementById('orbit-reply-text').value;
    navigator.clipboard.writeText(text);
    showToast('Reply copied to clipboard!');
  });
  
  document.getElementById('orbit-insert-reply').addEventListener('click', () => {
    const text = document.getElementById('orbit-reply-text').value;
    insertReplyIntoForm(commentElement, text);
    modal.remove();
    showToast('Reply inserted!');
  });
}

// Insert reply into platform's reply form
function insertReplyIntoForm(commentElement, text) {
  // Platform-specific form finding
  const replyForm = commentElement.closest('[class*="comment"], [class*="review"]').parentElement
    .querySelector('textarea, [contenteditable], input[type="text"]');
  
  if (replyForm) {
    if (replyForm.tagName === 'TEXTAREA' || replyForm.tagName === 'INPUT') {
      replyForm.value = text;
    } else if (replyForm.contentEditable === 'true') {
      replyForm.textContent = text;
    }
    replyForm.focus();
  }
}

// Toggle analytics panel
function toggleAnalytics() {
  const panel = document.getElementById('orbit-analytics-panel');
  panel.classList.toggle('hidden');
  
  if (!panel.classList.contains('hidden')) {
    loadAnalytics();
  }
}

// Load and display analytics
async function loadAnalytics() {
  const content = document.getElementById('orbit-analytics-content');
  
  // Extract sales data from page
  const salesData = extractSalesData();
  
  if (!salesData || salesData.length === 0) {
    content.innerHTML = `
      <div class="orbit-empty-state">
        <p>No sales data detected on this page.</p>
        <p>Navigate to your dashboard or sales reports to see analytics.</p>
      </div>
    `;
    return;
  }
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'analyzeSales',
      data: salesData
    });
    
    if (response.success) {
      renderAnalytics(response.analysis);
    } else {
      content.innerHTML = `<div class="orbit-error">${response.error}</div>`;
    }
  } catch (error) {
    content.innerHTML = `<div class="orbit-error">Failed to load analytics</div>`;
  }
}

// Extract sales data from page (platform-specific)
function extractSalesData() {
  // This is a simplified version - would need platform-specific selectors
  const data = [];
  
  // Look for table rows or data containers
  const rows = document.querySelectorAll('table tr, [class*="row"], [class*="item"]');
  
  rows.forEach(row => {
    const cells = row.querySelectorAll('td, [class*="cell"]');
    if (cells.length >= 3) {
      data.push({
        date: cells[0]?.textContent?.trim(),
        product: cells[1]?.textContent?.trim(),
        revenue: parseFloat(cells[2]?.textContent?.replace(/[^0-9.]/g, '')) || 0
      });
    }
  });
  
  return data;
}

// Render analytics data
function renderAnalytics(analysis) {
  const content = document.getElementById('orbit-analytics-content');
  
  let insightsHtml = '';
  if (analysis.keyInsights) {
    insightsHtml = analysis.keyInsights.map(insight => `
      <div class="insight-card ${insight.type}">
        <div class="insight-icon">${getInsightIcon(insight.type)}</div>
        <div class="insight-content">
          <h4>${insight.title}</h4>
          <p>${insight.description}</p>
          <span class="insight-action">→ ${insight.action}</span>
        </div>
      </div>
    `).join('');
  }
  
  content.innerHTML = `
    <div class="analytics-summary">
      <h4>${analysis.summary || 'Sales Analysis'}</h4>
    </div>
    <div class="metrics-grid">
      <div class="metric-card">
        <span class="metric-value">$${analysis.metrics?.totalRevenue?.toLocaleString() || 0}</span>
        <span class="metric-label">Total Revenue</span>
      </div>
      <div class="metric-card">
        <span class="metric-value">${analysis.metrics?.conversionRate?.toFixed(1) || 0}%</span>
        <span class="metric-label">Conversion Rate</span>
      </div>
      <div class="metric-card">
        <span class="metric-value">${analysis.metrics?.refundRate?.toFixed(1) || 0}%</span>
        <span class="metric-label">Refund Rate</span>
      </div>
      <div class="metric-card">
        <span class="metric-value">$${analysis.metrics?.avgOrderValue?.toFixed(2) || 0}</span>
        <span class="metric-label">Avg Order Value</span>
      </div>
    </div>
    <div class="insights-list">
      ${insightsHtml}
    </div>
  `;
}

function getInsightIcon(type) {
  const icons = {
    opportunity: '🚀',
    warning: '⚠️',
    trend: '📈'
  };
  return icons[type] || '💡';
}

// Analyze keywords
async function analyzeKeywords() {
  const panel = document.getElementById('orbit-keywords-panel');
  panel.classList.remove('hidden');
  
  const content = document.getElementById('orbit-keywords-content');
  content.innerHTML = '<div class="loading">Scanning comments with AI...</div>';
  
  const comments = findComments().map(c => ({
    text: c.textContent,
    author: c.querySelector('[class*="author"]')?.textContent || 'Anonymous'
  }));
  
  if (comments.length === 0) {
    content.innerHTML = `
      <div class="orbit-empty-state">
        <p>No comments found on this page.</p>
      </div>
    `;
    return;
  }
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'getKeywords',
      data: { comments }
    });
    
    if (response.success) {
      renderKeywords(response.keywords);
    } else {
      content.innerHTML = `<div class="orbit-error">${response.error}</div>`;
    }
  } catch (error) {
    content.innerHTML = `<div class="orbit-error">Analysis failed</div>`;
  }
}

// Render keyword analysis
function renderKeywords(keywords) {
  const content = document.getElementById('orbit-keywords-content');
  
  const featureRequests = keywords.featureRequests?.map(f => `
    <div class="keyword-item priority-${f.priority}">
      <span class="keyword-name">${f.feature}</span>
      <span class="keyword-count">${f.mentions} mentions</span>
    </div>
  `).join('') || '<p>No feature requests found</p>';
  
  const painPoints = keywords.painPoints?.map(p => `
    <div class="keyword-item trend-${p.trend}">
      <span class="keyword-name">${p.issue}</span>
      <span class="keyword-count">${p.mentions} mentions</span>
    </div>
  `).join('') || '<p>No pain points identified</p>';
  
  content.innerHTML = `
    <div class="sentiment-overview">
      <div class="sentiment-score ${keywords.sentiment?.overall}">
        <span class="score">${keywords.sentiment?.score || 0}/100</span>
        <span class="label">Sentiment Score</span>
      </div>
    </div>
    
    <div class="keywords-section">
      <h4>🔥 Feature Requests</h4>
      <div class="keywords-list">${featureRequests}</div>
    </div>
    
    <div class="keywords-section">
      <h4>⚠️ Pain Points</h4>
      <div class="keywords-list">${painPoints}</div>
    </div>
  `;
}

// Analyze entire dashboard
async function analyzeDashboard() {
  showToast('🤖 Analyzing your dashboard...', 3000);
  
  // Trigger both analytics and keywords
  await Promise.all([
    loadAnalytics(),
    analyzeKeywords()
  ]);
  
  // Show panels
  document.getElementById('orbit-analytics-panel').classList.remove('hidden');
  document.getElementById('orbit-keywords-panel').classList.remove('hidden');
  
  showToast('✅ Analysis complete!');
}

// Observe DOM changes for dynamic content
function observeDashboardChanges() {
  const observer = new MutationObserver((mutations) => {
    // Check if new comments were added
    const hasNewComments = mutations.some(mutation => 
      Array.from(mutation.addedNodes).some(node => 
        node.nodeType === 1 && (
          node.matches?.('[class*="comment"]') ||
          node.querySelector?.('[class*="comment"]')
        )
      )
    );
    
    if (hasNewComments) {
      setTimeout(injectReplyButtons, 500);
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// Extract dashboard data periodically
function extractDashboardData() {
  injectReplyButtons();
  
  // Refresh every 5 seconds for dynamic content
  setInterval(() => {
    if (orbitState.isActive) {
      injectReplyButtons();
    }
  }, 5000);
}

// Update quick stats display
async function updateQuickStats() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getStats' });
    if (response.success) {
      const responsesEl = document.getElementById('orbit-stat-responses');
      const timeEl = document.getElementById('orbit-stat-time');
      
      if (responsesEl) responsesEl.textContent = response.stats.responsesGenerated;
      if (timeEl) timeEl.textContent = Math.floor(response.stats.timeSaved / 60) + 'h';
    }
  } catch (error) {
    console.error('Failed to update stats:', error);
  }
}

// Show toast notification
function showToast(message, duration = 2000) {
  const toast = document.createElement('div');
  toast.className = 'orbit-toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, duration);
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'refreshUI') {
    updateQuickStats();
    sendResponse({ success: true });
  }
});

console.log('✅ ORBIT Content Script Ready');